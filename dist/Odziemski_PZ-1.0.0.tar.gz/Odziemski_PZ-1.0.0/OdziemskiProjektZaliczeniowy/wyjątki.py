class BłądNazwyPliku(Exception):
    pass

class NiewłaściwaLiczbaNazw(Exception):
    pass